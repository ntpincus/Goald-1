package io.google.citrix.goald;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by ntpin on 5/19/2016.
 */
public class CreateGoal extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.goal_dialog);
    }
}
